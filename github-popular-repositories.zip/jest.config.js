module.exports = {
    "testEnvironment": "jsdom",
    testEnvironmentOptions: {
        url: "http://localhost:8888/",
      },
}